Installation Steps:

- Create a database 'titangym';
- Import the titangym.sql file located on the project folder
- Open the project file

Login details for admin
(use this detail to login)
userid- admin1
password - admin1



Sample user details only
userid - 1529336794
name- Christiana Mayberry
email- christiani@gmail.com